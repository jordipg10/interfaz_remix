subroutine read_exchange_react_PHREEQC(this,string,prim_flag,defined_species)
    use eq_reaction_m, only: eq_reaction_c
    use species_m, only: species_c
    use strings_m
    implicit none
    class(eq_reaction_c) :: this
    character(len=*), intent(in) :: string !> half reaction
    logical, intent(out) :: prim_flag !> TRUE if species is primary
    type(species_c), intent(out), optional :: defined_species !> defined exchange species
    
    integer(kind=4) :: i,j,k,n,num_reactants,n_ions,eq_ind,ind_init,plus_ind,minus_ind,sign_ind,hash_ind
    real(kind=8) :: logK
    real(kind=8), allocatable :: electr_valences(:)
    character(len=256) :: str
    character(len=256), allocatable :: str_arr(:),species_names(:)
    logical :: flag
    type(species_c), allocatable :: local_species(:)
    
    
    n=len_trim(string)

    ind_init=1
    do i=1,n
        if (string(i:i)=='') then
            ind_init=ind_init+1
        else
            exit
        end if
    end do
    
    this%num_species=1
    eq_ind=index(string,'=')
    hash_ind=index(string,'#')
    if (string(ind_init:eq_ind-2)==string(eq_ind+2:n) .and. hash_ind==0) then
        prim_flag=.true.
        if (present(defined_species)) then
            call defined_species%set_name(string(ind_init:eq_ind-2))
        end if
    else if (string(ind_init:eq_ind-2)==string(eq_ind+2:hash_ind-2) .and. hash_ind>0) then
        prim_flag=.true.
        if (present(defined_species)) then
            call defined_species%set_name(string(ind_init:eq_ind-2))
        end if
    else
        prim_flag=.false.
        do i=ind_init,n-2
            if (string(i:i+2)==' + ' .or. string(i:i+2)==' - ' .or. string(i:i+2)==' = ') then
                this%num_species=this%num_species+1
            else
                continue
            end if
        end do
        call this%allocate_reaction()
        allocate(local_species(this%num_species))
        j=1
        k=ind_init
        i=ind_init
        do while (j<this%num_species)
            if (string(i:i+2)==' + ' .or. string(i:i+2)==' - ') then
                call local_species(j)%set_name(string(k:i-1))
                if (string(i-1:i-1)=='+') then
                    call local_species(j)%set_valence(1)
                else if (string(i-1:i-1)=='-') then
                    call local_species(j)%set_valence(-1)
                else if (string(i-2:i-2)=='+' .or. string(i-2:i-2)=='-') then
                    read(string(i-1:i-1),*) local_species(j)%valence
                end if
                k=i+3
                j=j+1
            end if
            if (i<n-2) then
                i=i+1
            else
                exit
            end if
        end do
        plus_ind=index(string(eq_ind+1:n),'+')+eq_ind
        minus_ind=index(string(eq_ind+1:n),'-')+eq_ind
        if (plus_ind>eq_ind .and. minus_ind>eq_ind) then
            sign_ind=min(plus_ind,minus_ind)
        else if (plus_ind>eq_ind) then
            sign_ind=plus_ind
        else if (minus_ind>eq_ind) then
            sign_ind=minus_ind
        else
            sign_ind=n+2
        end if
        if (present(defined_species)) then
            call defined_species%set_name(string(eq_ind+2:sign_ind-2))
        end if
        call local_species(j)%set_name(string(eq_ind+2:sign_ind-2))
        j=j+1
    end if
end subroutine