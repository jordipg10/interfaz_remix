!> \file spatial_discr_1D_m.f90
!> \brief One-dimensional spatial discretization module.
!> \details
!> Defines homogeneous and heterogeneous 1D Eulerian mesh types extending
!> the abstract `spatial_discr_c` base class. Supports reading mesh data
!> from files, computing cell sizes, domain measure, target indices, and
!> mesh refinement.
!>
!> \par Mesh Types:
!> - `mesh_1D_Euler_homog_c`  : uniform cell size \f$\Delta x\f$
!> - `mesh_1D_Euler_heterog_c`: variable cell sizes \f$\Delta x_i\f$
!>
!> \see spatial_discr_m, spatial_discr_2D_m, spatial_discr_rad_m
!> \author Jordi
!> \date Unknown
!> \ingroup discretization

!> \brief 1D spatial discretization module.
module spatial_discr_1D_m
    use spatial_discr_m, only: spatial_discr_c
    use vectors_m, only: inf_norm_vec_real
    implicit none
    save
    private
    !> \brief Homogeneous 1D Eulerian mesh with uniform cell size.
    !> \details All cells have the same width \f$\Delta x = L / N\f$.
    type, public, extends(spatial_discr_c) :: mesh_1D_Euler_homog_c
        real(kind=8) :: Delta_x      !< [L] Uniform cell size
        real(kind=8) :: Delta_x_D    !< [-] Dimensionless cell size
    contains
        procedure :: set_Delta_x_homog
        procedure :: read_mesh=>read_mesh_homog
        procedure :: get_Cell_size=>get_Delta_x_homog
        procedure :: get_max_cell_size=>get_max_Delta_x_homog
        procedure :: compute_measure=>compute_measure_homog
        procedure :: compute_Delta_x=>compute_Delta_x_1D_homog
        procedure :: compute_Num_targets=>compute_Num_targets_1D_homog
        procedure :: check_exit=>check_exit_1D_homog
        procedure :: refine_mesh=>refine_mesh_homog
        procedure :: compute_dimless_mesh=>compute_dimless_mesh_1D_homog
        procedure :: compute_final_point=>compute_final_point_1D_homog
        procedure :: get_target_ind=>get_target_ind_1D_homog
        procedure :: get_num_cells=>get_num_cells_1D_homog
    end type
    
    !> \brief Heterogeneous 1D Eulerian mesh with variable cell sizes.
    !> \details Each cell \f$i\f$ has its own width \f$\Delta x_i\f$.
    type, public, extends(spatial_discr_c) :: mesh_1D_Euler_heterog_c
        real(kind=8), allocatable :: Delta_x(:)    !< [L] Cell sizes array
        real(kind=8), allocatable :: Delta_x_D(:)  !< [-] Dimensionless cell sizes
    contains
        procedure :: set_Delta_x_heterog
        procedure :: read_mesh=>read_mesh_heterog
        procedure :: get_Cell_size=>get_Delta_x_heterog
        procedure :: get_max_cell_size=>get_max_Delta_x_heterog
        procedure :: compute_measure=>compute_measure_heterog
        procedure :: check_exit=>check_exit_1D_heterog
        procedure :: refine_mesh=>refine_mesh_heterog
        procedure :: compute_dimless_mesh=>compute_dimless_mesh_1D_heterog
        procedure :: get_target_ind=>get_target_ind_1D_heterog
        procedure :: compute_Num_targets=>compute_Num_targets_1D_heterog
        procedure :: get_num_cells=>get_num_cells_1D_heterog
    end type
    
    interface
        
        
        
    end interface
    
    contains
        subroutine set_Delta_x_homog(this,Delta_x)
            implicit none
            class(mesh_1D_Euler_homog_c) :: this
            real(kind=8), intent(in) :: Delta_x
            this%Delta_x=Delta_x
        end subroutine
        
        subroutine set_Delta_x_heterog(this,Delta_x)
            implicit none
            class(mesh_1D_Euler_heterog_c) :: this
            real(kind=8), intent(in) :: Delta_x(:)
            this%Delta_x=Delta_x
        end subroutine
        
        subroutine read_mesh_homog(this,filename,phi)
            implicit none
            class(mesh_1D_Euler_homog_c) :: this
            character(len=*), intent(in) :: filename
            real(kind=8), intent(in), optional :: phi
            
            integer(kind=4) :: i !> Loop index
            real(kind=8) :: coords(1) !> Coordinates of the targets (1D)
            character(len=256) :: label !> Label for reading file
            
            allocate(this%init_point(1),this%final_point(1))
            open(unit=1,file=filename,status='old',action='read')
            do
                ! read(1,*,iostat=i) !> Skip possible blank lines
                ! if (i==0) exit
                read(1,*) label
                if (trim(label)=='SPATIAL DISCRETISATION') then
                    read(1,*) this%scheme
                    read(1,*) this%targets_flag
                    read(1,*) this%measure
                    read(1,*) this%Num_targets
                    read(1,*) this%init_point
                    read(1,*) this%adapt_ref
                else if (trim(label)=='end') then
                    exit
                else
                    continue
                end if
            end do
            close(1)
            call this%set_dim(1) !> Set dimension to 1D
            this%Num_targets_defined=.true.
            call this%compute_Delta_x()
            call this%allocate_targets()
            !> First target
            call this%targets(1)%set_id(1)
            call this%targets(1)%set_boundary_flag(.true.)
            call this%targets(1)%set_measure(this%Delta_x*(1-this%targets_flag))
            coords=this%init_point+this%Delta_x*(1d0-1d0/(2d0-this%targets_flag))
            call this%targets(1)%set_coordinates(coords)
            !> Non-boundary targets
            do i=2,this%Num_targets-1
                call this%targets(i)%set_id(i)
                call this%targets(i)%set_boundary_flag(.false.)
                call this%targets(i)%set_measure(this%Delta_x*(1-this%targets_flag))
                coords=this%init_point+this%Delta_x*(i-1d0/(2d0-this%targets_flag))
                call this%targets(i)%set_coordinates(coords)
            end do
            !> Last target
            call this%targets(this%Num_targets)%set_id(this%Num_targets)
            call this%targets(this%Num_targets)%set_boundary_flag(.true.)
            call this%targets(this%Num_targets)%set_measure(this%Delta_x*(1-this%targets_flag))
            coords=this%init_point+this%Delta_x*(this%Num_targets-1d0/(2d0-this%targets_flag))
            call this%targets(this%Num_targets)%set_coordinates(coords)
            call this%compute_final_point()
        end subroutine
        
        subroutine read_mesh_heterog(this,filename,phi)
            implicit none
            class(mesh_1D_Euler_heterog_c) :: this
            character(len=*), intent(in) :: filename
            real(kind=8), intent(in), optional :: phi
            
            open(unit=1,file=filename,status='old',action='read')
            read(1,"(/,I10)") this%scheme
            read(1,*) this%targets_flag
            read(1,*) this%Num_targets
            allocate(this%Delta_x(this%Num_targets))
            read(1,*) this%Delta_x
            close(1)
            call this%set_dim(1) !> Set dimension to 1D
            call this%compute_measure()
        end subroutine
        
        function get_Delta_x_homog(this,i) result(Delta_x)
            implicit none
            class(mesh_1D_Euler_homog_c) :: this
            integer(kind=4), intent(in), optional :: i
            real(kind=8) :: Delta_x
            Delta_x=this%Delta_x
        end function
        
        function get_Delta_x_heterog(this,i) result(Delta_x)
            implicit none
            class(mesh_1D_Euler_heterog_c) :: this
            integer(kind=4), intent(in), optional :: i
            real(kind=8) :: Delta_x
            if (present(i)) then
                Delta_x=this%Delta_x(i) ! return cell size at index i
            else
                Delta_x=this%Delta_x(1) ! return cell size at index 1 by default
            end if
        end function
        
        subroutine compute_measure_homog(this)
            implicit none
            class(mesh_1D_Euler_homog_c) :: this
            this%measure=(this%Num_targets-this%targets_flag)*this%Delta_x
        end subroutine
        
        subroutine compute_measure_heterog(this)
            implicit none
            class(mesh_1D_Euler_heterog_c) :: this
            this%measure=sum(this%Delta_x)
        end subroutine
        
        subroutine compute_Delta_x_1D_homog(this)
            implicit none
            class(mesh_1D_Euler_homog_c) :: this
            this%Delta_x=this%measure/(this%Num_targets-this%targets_flag)
        end subroutine
        
        subroutine compute_Num_targets_1D_homog(this)
            implicit none
            class(mesh_1D_Euler_homog_c) :: this
            this%Num_targets=this%measure/this%Delta_x + this%targets_flag
        end subroutine

        subroutine compute_Num_targets_1D_heterog(this)
            implicit none
            class(mesh_1D_Euler_heterog_c) :: this
            this%Num_targets=size(this%Delta_x) + this%targets_flag
        end subroutine
        
        function get_dim_1D_homog(this) result(dim)
            implicit none
            class(mesh_1D_Euler_homog_c) :: this
            integer(kind=4) :: dim
            dim=1
        end function
        
        function get_dim_1D_heterog(this) result(dim)
            implicit none
            class(mesh_1D_Euler_heterog_c) :: this
            integer(kind=4) :: dim
            dim=1
        end function
        
        subroutine compute_dimless_mesh_1D_homog(this,char_length)
        implicit none
        class(mesh_1D_Euler_homog_c) :: this
        real(kind=8), intent(in) :: char_length !> Characteristic measure for dimensionless form
        !if (this%dimless) then
            this%Delta_x_D=this%Delta_x/char_length
            this%measure_D=this%measure/char_length
            !this%init_point=this%init_point/char_measure
        !end if
        end subroutine
        
        subroutine compute_dimless_mesh_1D_heterog(this,char_length)
        implicit none
        class(mesh_1D_Euler_heterog_c) :: this
        real(kind=8), intent(in) :: char_length !> Characteristic measure for dimensionless form
        this%Delta_x_D=this%Delta_x/char_length
        this%measure_D=this%measure/char_length
        !this%init_point=this%init_point/char_length
        end subroutine

        subroutine check_exit_1D_homog(this,coords,exit_flag)
            implicit none
            class(mesh_1D_Euler_homog_c) :: this
            real(kind=8), intent(in) :: coords(:) !> Coordinates to check
            logical, intent(out) :: exit_flag !> exit flag
            
            exit_flag=.false.
            if (coords(1)<this%init_point(1) .or. coords(1)>this%final_point(1)) then
                print *, "Error: Coordinates out of bounds."
                exit_flag=.true.
            end if
        end subroutine

        subroutine check_exit_1D_heterog(this,coords,exit_flag)
            implicit none
            class(mesh_1D_Euler_heterog_c) :: this
            real(kind=8), intent(in) :: coords(:) !> Coordinates to check
            logical, intent(out) :: exit_flag

            exit_flag=.false.
            if (coords(1)<this%init_point(1) .or. coords(1)>this%final_point(1)) then
                print *, "Error: Coordinates out of bounds."
                exit_flag=.true.
            end if
        end subroutine

        function get_target_ind_1D_homog(this,coord) result(target_ind)
            implicit none
            class(mesh_1D_Euler_homog_c) :: this !> spatial discretisation class
            real(kind=8), intent(in) :: coord(:) !> space coordinates
            integer(kind=4) :: target_ind !> target index
            
            integer(kind=4) :: i
            
            if (size(coord)/=1) error stop "Dimension error in get_target_ind_1D_homog"
            
            target_ind=0 ! Default value
            
            do i=1,this%Num_targets
                if (abs(coord(1)-this%targets(i)%coord(1)) < this%Delta_x/2d0) then
                    target_ind=i
                    return
                end if
            end do
            
        end function get_target_ind_1D_homog

        function get_target_ind_1D_heterog(this,coord) result(target_ind)
            implicit none
            class(mesh_1D_Euler_heterog_c) :: this !> spatial discretisation class
            real(kind=8), intent(in) :: coord(:) !> space coordinates
            integer(kind=4) :: target_ind !> target index

            integer(kind=4) :: i

            if (size(coord)/=1) error stop "Dimension error in get_target_ind_1D_heterog"

            target_ind=0 ! Default value

            if (coord(1) < this%init_point(1) .or. coord(1) > this%final_point(1)) then
                print *, "Error: Coordinates out of bounds."
                return
            end if
            if (coord(1) <= this%init_point(1) + 0.5*this%Delta_x(1)) then
                target_ind = 1 ! Set target index for the first target
                return
            end if
            do i=2,this%Num_targets-1
                if (coord(1)<=this%targets(i-1)%coord(1)+0.5*this%Delta_x(i-1)) then
                    target_ind = i-1 ! Set target index
                    return
                else if (coord(1)<=this%targets(i)%coord(1)) then
                    target_ind = i ! Set target index
                    return
                else
                    continue ! Continue to next target
                end if
            end do
            if (coord(1) <= this%final_point(1)) then
                target_ind = this%Num_targets ! Set target index for the last target
                return
            end if

        end function get_target_ind_1D_heterog
        
        function get_max_Delta_x_heterog(this) result(max_cell_size)
        class(mesh_1D_Euler_heterog_c), intent(in) :: this
        real(kind=8) :: max_cell_size
        max_cell_size=maxval(this%Delta_x)
        end function
        
        function get_max_Delta_x_homog(this) result(max_cell_size)
        class(mesh_1D_Euler_homog_c), intent(in) :: this
        real(kind=8) :: max_cell_size
        max_cell_size=this%Delta_x
        end function

        subroutine refine_mesh_heterog(this,conc,conc_ext,rel_tol)
            implicit none
            class(mesh_1D_Euler_heterog_c) :: this
            real(kind=8), intent(inout), allocatable :: conc(:,:) !> Num_columns=Num_targets
            real(kind=8), intent(inout), allocatable :: conc_ext(:,:) !> Num_columns=Num_targets
            real(kind=8), intent(in) :: rel_tol !> relative tolerance
            integer(kind=4) :: j,n
            real(kind=8), allocatable :: Delta_x_new(:)
            
            n=this%Num_targets
            
            do j=1,n-1
                if (inf_norm_vec_real(conc(:,j)-conc(:,j+1))/inf_norm_vec_real(conc(:,j))>=rel_tol) then
                    Delta_x_new=[Delta_x_new,this%Delta_x(j)/2,this%Delta_x(j)/2]
                else
                    Delta_x_new=[Delta_x_new,this%Delta_x(j)]
                end if
            end do
            deallocate(this%Delta_x)
            this%Delta_x=Delta_x_new
            this%Num_targets=size(this%Delta_x)
        end subroutine

        subroutine refine_mesh_homog(this,conc,conc_ext,rel_tol)
            implicit none
            class(mesh_1D_Euler_homog_c) :: this
            real(kind=8), intent(inout), allocatable :: conc(:,:) !> Num_columns=Num_targets
            real(kind=8), intent(inout), allocatable :: conc_ext(:,:) !> Num_columns=Num_targets
            real(kind=8), intent(in) :: rel_tol !> relative tolerance

            real(kind=8), allocatable :: conc_ref(:,:)
            real(kind=8), allocatable :: conc_ext_ref(:,:)
    
            integer(kind=4) :: j,n,ratio
            real(kind=8) :: Delta_x_old,Delta_x_new
            
            n=this%Num_targets
            Delta_x_old=this%Delta_x
            Delta_x_new=Delta_x_old
            do j=1,n-1
                if (inf_norm_vec_real(conc(:,j)-conc(:,j+1))/inf_norm_vec_real(conc(:,j))>=rel_tol) then
                    Delta_x_new=Delta_x_old/2
                    Delta_x_old=Delta_x_new
                end if
            end do
            if (Delta_x_new<this%Delta_x) then
                ratio=nint(this%Delta_x/Delta_x_new)
                this%Num_targets=this%Num_targets*ratio
                this%Delta_x=Delta_x_new
                allocate(conc_ref(size(conc,1),this%Num_targets),conc_ext_ref(size(conc_ext,1),this%Num_targets))
                do j=1,this%Num_targets
                    conc_ref(:,j)=conc(:,ceiling(j/(1d0*ratio)))
                    conc_ext_ref(:,j)=conc_ext(:,ceiling(j/(1d0*ratio)))
                end do
                deallocate(conc,conc_ext)
                conc=conc_ref
                conc_ext=conc_ext_ref
            end if
        end subroutine

        subroutine compute_final_point_1D_homog(this)
            !> Compute final point based on initial point and measure
            implicit none
            class(mesh_1D_Euler_homog_c) :: this
            this%final_point(1)=this%init_point(1)+this%measure
        end subroutine
        
        function get_num_cells_1D_homog(this,dim) result(num_cells)
            class(mesh_1D_Euler_homog_c), intent(in) :: this
            integer(kind=4), intent(in), optional :: dim
            integer(kind=4) :: num_cells
            num_cells=this%Num_targets-this%targets_flag
        end function get_num_cells_1D_homog
        
        function get_num_cells_1D_heterog(this,dim) result(num_cells)
            class(mesh_1D_Euler_heterog_c), intent(in) :: this
            integer(kind=4), intent(in), optional :: dim
            integer(kind=4) :: num_cells
            num_cells=this%Num_targets-this%targets_flag
        end function get_num_cells_1D_heterog

end module
